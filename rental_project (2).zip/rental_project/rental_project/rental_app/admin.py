from django.contrib import admin
from .models import Property, PropertyImage, Review, Booking, UserProfile

class PropertyImageInline(admin.TabularInline):
    model = PropertyImage
    extra = 3

class ReviewInline(admin.TabularInline):
    model = Review
    extra = 0
    readonly_fields = ['user', 'rating', 'comment', 'created_at']

class PropertyAdmin(admin.ModelAdmin):
    list_display = ('title', 'owner', 'city', 'property_type', 'price_per_night', 'is_available')
    list_filter = ('is_available', 'property_type', 'city')
    search_fields = ('title', 'description', 'address', 'city')
    inlines = [PropertyImageInline, ReviewInline]

class BookingAdmin(admin.ModelAdmin):
    list_display = ('property', 'user', 'check_in_date', 'check_out_date', 'status')
    list_filter = ('status',)
    search_fields = ('property__title', 'user__username')

class ReviewAdmin(admin.ModelAdmin):
    list_display = ('property', 'user', 'rating', 'created_at')
    list_filter = ('rating',)
    search_fields = ('property__title', 'user__username', 'comment')

admin.site.register(Property, PropertyAdmin)
admin.site.register(PropertyImage)
admin.site.register(Review, ReviewAdmin)
admin.site.register(Booking, BookingAdmin)
admin.site.register(UserProfile)