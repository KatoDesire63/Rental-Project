from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.db.models import Avg
from django.http import HttpResponseForbidden
from django.contrib.auth.models import User
from django.contrib.auth.forms import UserCreationForm
from django.urls import reverse_lazy
from django.views.generic.edit import CreateView
from datetime import datetime
from decimal import Decimal

from .models import Property, PropertyImage, Review, UserProfile, Booking
from .forms import (
    UserRegisterForm, UserProfileForm, PropertyForm, 
    PropertyImageFormSet, ReviewForm, BookingForm
)

def home(request):
    properties = Property.objects.filter(is_available=True).order_by('-created_at')
    return render(request, 'rental_app/home.html', {'properties': properties})

def property_list(request):
    properties = Property.objects.filter(is_available=True).order_by('-created_at')
    return render(request, 'rental_app/property_list.html', {'properties': properties})

def property_detail(request, pk):
    property = get_object_or_404(Property, pk=pk)
    reviews = property.reviews.all().order_by('-created_at')
    review_form = ReviewForm()
    booking_form = BookingForm()
    
    # Check if user has already reviewed this property
    user_has_reviewed = False
    if request.user.is_authenticated:
        user_has_reviewed = Review.objects.filter(property=property, user=request.user).exists()
    
    context = {
        'property': property,
        'reviews': reviews,
        'review_form': review_form,
        'booking_form': booking_form,
        'user_has_reviewed': user_has_reviewed,
    }
    return render(request, 'rental_app/property_detail.html', context)

@login_required
def add_property(request):
    if request.method == 'POST':
        form = PropertyForm(request.POST)
        formset = PropertyImageFormSet(request.POST, request.FILES)
        
        if form.is_valid() and formset.is_valid():
            property = form.save(commit=False)
            property.owner = request.user
            property.save()
            
            # Save the image formset
            instances = formset.save(commit=False)
            for instance in instances:
                instance.property = property
                instance.save()
            
            messages.success(request, 'Property added successfully!')
            return redirect('property_detail', pk=property.pk)
    else:
        form = PropertyForm()
        formset = PropertyImageFormSet()
    
    return render(request, 'rental_app/add_property.html', {
        'form': form,
        'formset': formset
    })

@login_required
def edit_property(request, pk):
    property = get_object_or_404(Property, pk=pk)
    
    # Check if the user is the owner
    if property.owner != request.user:
        return HttpResponseForbidden("You don't have permission to edit this property.")
    
    if request.method == 'POST':
        form = PropertyForm(request.POST, instance=property)
        formset = PropertyImageFormSet(request.POST, request.FILES, instance=property)
        
        if form.is_valid() and formset.is_valid():
            form.save()
            formset.save()
            messages.success(request, 'Property updated successfully!')
            return redirect('property_detail', pk=property.pk)
    else:
        form = PropertyForm(instance=property)
        formset = PropertyImageFormSet(instance=property)
    
    return render(request, 'rental_app/edit_property.html', {
        'form': form,
        'formset': formset,
        'property': property
    })

@login_required
def delete_property(request, pk):
    property = get_object_or_404(Property, pk=pk)
    
    # Check if the user is the owner
    if property.owner != request.user:
        return HttpResponseForbidden("You don't have permission to delete this property.")
    
    if request.method == 'POST':
        property.delete()
        messages.success(request, 'Property deleted successfully!')
        return redirect('my_properties')
    
    return render(request, 'rental_app/delete_property.html', {'property': property})

@login_required
def add_review(request, pk):
    property = get_object_or_404(Property, pk=pk)
    
    # Check if user has already reviewed this property
    if Review.objects.filter(property=property, user=request.user).exists():
        messages.error(request, 'You have already reviewed this property.')
        return redirect('property_detail', pk=property.pk)
    
    if request.method == 'POST':
        form = ReviewForm(request.POST)
        if form.is_valid():
            review = form.save(commit=False)
            review.property = property
            review.user = request.user
            review.save()
            messages.success(request, 'Review added successfully!')
            return redirect('property_detail', pk=property.pk)
    
    return redirect('property_detail', pk=property.pk)

@login_required
def book_property(request, pk):
    property = get_object_or_404(Property, pk=pk)
    
    if request.method == 'POST':
        form = BookingForm(request.POST)
        if form.is_valid():
            booking = form.save(commit=False)
            booking.property = property
            booking.user = request.user
            
            # Calculate total price
            check_in = booking.check_in_date
            check_out = booking.check_out_date
            days = (check_out - check_in).days
            booking.total_price = property.price_per_night * Decimal(days)
            
            booking.save()
            messages.success(request, 'Booking request submitted successfully!')
            return redirect('my_bookings')
    
    return redirect('property_detail', pk=property.pk)

@login_required
def my_properties(request):
    properties = Property.objects.filter(owner=request.user).order_by('-created_at')
    return render(request, 'rental_app/my_properties.html', {'properties': properties})

@login_required
def my_bookings(request):
    bookings = Booking.objects.filter(user=request.user).order_by('-created_at')
    return render(request, 'rental_app/my_bookings.html', {'bookings': bookings})

@login_required
def property_bookings(request, pk):
    property = get_object_or_404(Property, pk=pk)
    
    # Check if the user is the owner
    if property.owner != request.user:
        return HttpResponseForbidden("You don't have permission to view these bookings.")
    
    bookings = Booking.objects.filter(property=property).order_by('-created_at')
    return render(request, 'rental_app/property_bookings.html', {
        'property': property,
        'bookings': bookings
    })

@login_required
def update_booking_status(request, pk, status):
    booking = get_object_or_404(Booking, pk=pk)
    
    # Check if the user is the property owner
    if booking.property.owner != request.user:
        return HttpResponseForbidden("You don't have permission to update this booking.")
    
    if status in [s[0] for s in Booking.STATUS_CHOICES]:
        booking.status = status
        booking.save()
        messages.success(request, f'Booking status updated to {status}.')
    
    return redirect('property_bookings', pk=booking.property.pk)

@login_required
def profile(request):
    try:
        profile = request.user.profile
    except UserProfile.DoesNotExist:
        profile = UserProfile.objects.create(user=request.user)
    
    if request.method == 'POST':
        form = UserProfileForm(request.POST, request.FILES, instance=profile)
        if form.is_valid():
            form.save()
            messages.success(request, 'Profile updated successfully!')
            return redirect('profile')
    else:
        form = UserProfileForm(instance=profile)
    
    return render(request, 'rental_app/profile.html', {'form': form})

class RegisterView(CreateView):
    form_class = UserRegisterForm
    template_name = 'registration/register.html'
    success_url = reverse_lazy('login')
    
    def form_valid(self, form):
        response = super().form_valid(form)
        UserProfile.objects.create(user=self.object)
        messages.success(self.request, 'Account created successfully! You can now log in.')
        return response

def search_properties(request):
    query = request.GET.get('query', '')
    city = request.GET.get('city', '')
    property_type = request.GET.get('property_type', '')
    min_price = request.GET.get('min_price', '')
    max_price = request.GET.get('max_price', '')
    bedrooms = request.GET.get('bedrooms', '')
    
    properties = Property.objects.filter(is_available=True)
    
    if query:
        properties = properties.filter(title__icontains=query)
    
    if city:
        properties = properties.filter(city__icontains=city)
    
    if property_type:
        properties = properties.filter(property_type=property_type)
    
    if min_price:
        properties = properties.filter(price_per_night__gte=min_price)
    
    if max_price:
        properties = properties.filter(price_per_night__lte=max_price)
    
    if bedrooms:
        properties = properties.filter(bedrooms__gte=bedrooms)
    
    return render(request, 'rental_app/search_results.html', {
        'properties': properties,
        'query': query,
        'city': city,
        'property_type': property_type,
        'min_price': min_price,
        'max_price': max_price,
        'bedrooms': bedrooms,
    })