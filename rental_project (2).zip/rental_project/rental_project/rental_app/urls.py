from django.urls import path
from . import views

urlpatterns = [
    path('', views.home, name='home'),
    path('properties/', views.property_list, name='property_list'),
    path('properties/<int:pk>/', views.property_detail, name='property_detail'),
    path('properties/add/', views.add_property, name='add_property'),
    path('properties/<int:pk>/edit/', views.edit_property, name='edit_property'),
    path('properties/<int:pk>/delete/', views.delete_property, name='delete_property'),
    path('properties/<int:pk>/review/', views.add_review, name='add_review'),
    path('properties/<int:pk>/book/', views.book_property, name='book_property'),
    path('my-properties/', views.my_properties, name='my_properties'),
    path('my-bookings/', views.my_bookings, name='my_bookings'),
    path('properties/<int:pk>/bookings/', views.property_bookings, name='property_bookings'),
    path('bookings/<int:pk>/status/<str:status>/', views.update_booking_status, name='update_booking_status'),
    path('profile/', views.profile, name='profile'),
    path('register/', views.RegisterView.as_view(), name='register'),
    path('search/', views.search_properties, name='search_properties'),
]